import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * JUnit test class for solving square roots
 */
public class SquareRootTests {

    // TODO: Assignment 4 Part 2 -- Checkpoint4

    @Before public void setUp() throws Exception {
    }

    @After public void tearDown() throws Exception {
    }

    @Test public void testRandomPositiveSquareRoot() {
        // You cannot use the Math.sqrt() function in the test!
        
    }

    @Test public void testRandomNegitiveSquareRoot() {
        // The result should be a complex number i.e. Double.isNaN()
        
    }

    @Test public void testSquareRootofZero() {
        // You cannot use the Math.sqrt() function in the test!
        
    }

    @Test public void testSquareRootofOne() {
        // You cannot use the Math.sqrt() function in the test!
        
    }

}
