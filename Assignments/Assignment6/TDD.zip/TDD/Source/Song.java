/**
 * Assignment 6: Test Driven Development <br />
 * The {@code Song} class
 */
public class Song {
    // TODO: Assignment 6 -- complete this Song class to pass the tests

}
